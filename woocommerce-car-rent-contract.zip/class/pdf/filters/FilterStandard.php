<?php
namespace FPDM\Filters;

class FilterStandard
{

    function decode($data)
    {
        return $data;
    }

    function encode($data)
    {
        return $data;
    }
}

?>